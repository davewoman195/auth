from django.shortcuts import render, redirect
from django.http import HttpResponse
from django.contrib.auth.models import User, auth
from django.contrib import messages

# Create your views here.


def home(request):
    bottom_bar = {"home_page": "current"}
    return render(request, 'home.html', bottom_bar)


def about(request):
    bottom_bar = {"about_page": "current"}
    return render(request, 'about.html', bottom_bar)


def contact(request):
    bottom_bar = {"contact_page": "current"}
    return render(request, 'contact.html', bottom_bar)


def login(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']

        user = auth.authenticate(username=username, password=password)

        if user is not None:
            auth.login(request, user)
            return redirect('/')
        else:
            messages.info(request, "invalid credentials")
            return redirect('/login')
    else:
        bottom_bar = {"login_page": "current"}
        return render(request, 'login.html', bottom_bar)


def signup(request):
    if request.method == 'POST':
        first_name = request.POST['first_name']
        last_name = request.POST['last_name']
        username = request.POST['username']
        email = request.POST['email']
        password = request.POST['password']

        user = User.objects.create_user(
            last_name=last_name, first_name=first_name, username=username, email=email, password=password).save()
        return redirect('/login')
    else:
        return render(request, 'signup.html')


def logout(request):
    auth.logout(request)
    return redirect('/')


def profile(request):
    if request.method == 'POST':
        first_name = request.POST['first_name']
        last_name = request.POST['last_name']
        email = request.POST['email']
    else:
        bottom_bar = {"profile_page": "current"}
        return render(request, 'profile.html', bottom_bar)
